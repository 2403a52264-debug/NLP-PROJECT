# 🎭 Sentiment Analysis Web App (Flask)

A beginner-friendly sentiment analysis project using Python Flask and scikit-learn.

## 📁 Folder Structure

```
sentiment-analysis-flask/
├── app.py                  # Flask web server
├── train_model.py          # Model training script
├── check_dataset.py        # Dataset inspection helper
├── requirements.txt        # Python dependencies
├── .gitignore
├── dataset/
│   └── IMDB Dataset.csv    # Download from Kaggle (see below)
├── model/
│   ├── sentiment_model.pkl       # Saved trained model (auto-generated)
│   └── tfidf_vectorizer.pkl      # Saved vectorizer (auto-generated)
├── templates/
│   ├── index.html          # Home page with input form
│   └── result.html         # Result display page
└── static/
    └── css/
        └── style.css       # Stylesheet
```

## 🗂️ Recommended Kaggle Datasets (pick one)

| # | Dataset | Rows | Columns | Link |
|---|---------|------|---------|------|
| 1 | **IMDB 50K Movie Reviews** (recommended) | 50,000 | review, sentiment | https://www.kaggle.com/datasets/lakshmi25npathi/imdb-dataset-of-50k-movie-reviews |
| 2 | Twitter Sentiment Analysis | 1.6M | target, text | https://www.kaggle.com/datasets/kazanova/sentiment140 |
| 3 | Amazon Product Reviews | 4M | review, sentiment | https://www.kaggle.com/datasets/bittlingmayer/amazonreviews |

**We use dataset #1 (IMDB)** because it's simple (2 columns), small, and has clear labels.

## 🚀 Setup Commands (VS Code Terminal)

```bash
# 1. Create project folder
mkdir sentiment-analysis-flask
cd sentiment-analysis-flask

# 2. Create virtual environment
python -m venv venv

# 3. Activate it
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Download dataset from Kaggle and place CSV in dataset/ folder

# 6. Inspect dataset (optional)
python check_dataset.py

# 7. Train the model (run once)
python train_model.py

# 8. Start the Flask app
python app.py

# 9. Open browser → http://127.0.0.1:5000
```

## 📄 File Explanations (for Viva)

| File | Purpose |
|------|---------|
| `app.py` | Main Flask server. Loads saved model, accepts user input via form, predicts sentiment, renders result page. |
| `train_model.py` | Reads CSV, cleans text (removes HTML & special chars), converts to TF-IDF vectors, trains Logistic Regression, prints accuracy & confusion matrix, saves model. |
| `check_dataset.py` | Helper to print dataset columns, shape, and label distribution so you know which columns to use. |
| `requirements.txt` | Lists all Python packages needed. `pip install -r requirements.txt` installs them all. |
| `templates/index.html` | Home page with a textarea form. User types a review and clicks "Analyze Sentiment". |
| `templates/result.html` | Shows the predicted sentiment (Positive/Negative), confidence %, and the original review. |
| `static/css/style.css` | All visual styling — gradient background, card layout, responsive design. |
| `model/*.pkl` | Serialized model and vectorizer saved by joblib. Loaded by `app.py` at startup. |

## 🔑 Key Concepts (for Viva)

- **TF-IDF (Term Frequency–Inverse Document Frequency):** Converts text into numbers. Words that appear often in one document but rarely in others get higher scores.
- **Logistic Regression:** A simple classification algorithm. Predicts probability of each class (positive/negative).
- **joblib:** Saves Python objects (model, vectorizer) to disk so we don't retrain every time.
- **Flask:** A lightweight Python web framework. `@app.route` maps URLs to functions. `render_template` renders HTML files.
- **Confusion Matrix:** Shows true positives, true negatives, false positives, false negatives.

## 🧹 Handling Neutral Labels

If your dataset has a "neutral" class:
```python
# Simply filter it out before training:
df = df[df["sentiment"] != "neutral"]
```

## 📤 Upload to GitHub

```bash
git init
git add .
git commit -m "Sentiment analysis Flask project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/sentiment-analysis-flask.git
git push -u origin main
```

---

## 📝 Project Report Sections

### Title
**Sentiment Analysis of Movie Reviews using Machine Learning and Flask**

### Abstract
This project implements a web-based sentiment analysis application that classifies movie reviews as Positive or Negative. We use the IMDB 50K dataset, TF-IDF for feature extraction, and Logistic Regression for classification, achieving ~89% accuracy. The application is built with Python Flask and provides a simple web interface for real-time predictions.

### Introduction
Sentiment analysis is a Natural Language Processing (NLP) technique used to determine the emotional tone of text. It has applications in product review analysis, social media monitoring, and customer feedback systems. This project demonstrates a complete end-to-end pipeline: data preprocessing, model training, evaluation, and deployment as a web application.

### Methodology
1. **Dataset:** IMDB 50K Movie Reviews — 25,000 positive and 25,000 negative reviews.
2. **Preprocessing:** HTML tag removal, special character removal, lowercasing, and stopword removal via TF-IDF.
3. **Feature Extraction:** TF-IDF Vectorizer with a vocabulary limit of 5,000 features.
4. **Model:** Logistic Regression with max 1,000 iterations.
5. **Evaluation:** Train/test split (80/20), accuracy score, classification report, and confusion matrix.
6. **Deployment:** Flask web server with HTML templates and CSS styling.

### Results and Discussion
The Logistic Regression model achieved approximately 89% accuracy on the test set. The confusion matrix showed balanced performance across both classes. TF-IDF effectively captured important words, and the simple model proved sufficient for binary sentiment classification. The web interface successfully accepts user input and returns predictions in real time.

### Conclusion
This project demonstrates that effective sentiment analysis can be achieved with simple machine learning techniques. The combination of TF-IDF and Logistic Regression provides a good baseline. Future improvements could include using word embeddings (Word2Vec), deep learning models (LSTM), or pre-trained transformers (BERT).
