"""
app.py
------
Flask web app that loads the trained model and predicts sentiment
for user-entered text.

Run: python app.py
Then open http://127.0.0.1:5000 in your browser.
"""

from flask import Flask, render_template, request
import joblib, re

app = Flask(__name__)

# Load saved model and vectorizer once at startup
model      = joblib.load("model/sentiment_model.pkl")
vectorizer = joblib.load("model/tfidf_vectorizer.pkl")

def clean_text(text):
    """Same cleaning used during training."""
    text = re.sub(r"<.*?>", " ", text)
    text = re.sub(r"[^a-zA-Z\s]", " ", text)
    return text.lower().strip()

@app.route("/")
def home():
    """Show the home page with the input form."""
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    """Accept form input, predict sentiment, show result."""
    user_text = request.form.get("review", "")
    cleaned   = clean_text(user_text)
    vec       = vectorizer.transform([cleaned])
    prediction = model.predict(vec)[0]            # 'positive' or 'negative'
    confidence = model.predict_proba(vec).max()    # probability of predicted class

    return render_template(
        "result.html",
        review=user_text,
        sentiment=prediction.capitalize(),
        confidence=f"{confidence * 100:.1f}%"
    )

if __name__ == "__main__":
    app.run(debug=True)
