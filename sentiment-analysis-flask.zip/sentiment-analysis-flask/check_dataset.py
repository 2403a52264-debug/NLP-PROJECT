"""
check_dataset.py
----------------
Quick script to inspect dataset columns and first few rows.
Run: python check_dataset.py
"""
import pandas as pd

df = pd.read_csv("dataset/IMDB Dataset.csv")

print("Columns :", df.columns.tolist())
print("Shape   :", df.shape)
print("\nFirst 3 rows:")
print(df.head(3))
print("\nLabel distribution:")
print(df["sentiment"].value_counts())
