"""
train_model.py
--------------
Reads the CSV dataset, preprocesses text, trains a Logistic Regression
model using TF-IDF features, evaluates it, and saves the model + vectorizer.

Run once:  python train_model.py
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib, os, re

# ---------- 1. Load dataset ----------
# Using the IMDB 50K dataset from Kaggle (two columns: review, sentiment)
df = pd.read_csv("dataset/IMDB Dataset.csv")

print("Columns:", df.columns.tolist())
print("Shape  :", df.shape)
print("Labels :", df["sentiment"].value_counts().to_dict())

# ---------- 2. Simple text cleaning ----------
def clean_text(text):
    """Remove HTML tags, special chars, and lowercase."""
    text = re.sub(r"<.*?>", " ", text)       # strip HTML
    text = re.sub(r"[^a-zA-Z\s]", " ", text) # keep letters only
    return text.lower().strip()

df["clean"] = df["review"].apply(clean_text)

# ---------- 3. Split data ----------
X = df["clean"]
y = df["sentiment"]   # 'positive' or 'negative'

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"\nTrain size: {len(X_train)}, Test size: {len(X_test)}")

# ---------- 4. TF-IDF Vectorization ----------
vectorizer = TfidfVectorizer(max_features=5000, stop_words="english")
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec  = vectorizer.transform(X_test)

# ---------- 5. Train model ----------
model = LogisticRegression(max_iter=1000)
model.fit(X_train_vec, y_train)

# ---------- 6. Evaluate ----------
y_pred = model.predict(X_test_vec)

print("\n--- Results ---")
print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# ---------- 7. Save model and vectorizer ----------
os.makedirs("model", exist_ok=True)
joblib.dump(model, "model/sentiment_model.pkl")
joblib.dump(vectorizer, "model/tfidf_vectorizer.pkl")
print("\nModel and vectorizer saved in model/ folder.")
